package com.example.fragments.fragments

import androidx.fragment.app.Fragment
import com.example.fragments.R

class HomeFragment: Fragment(R.layout.fragment_home) {

}