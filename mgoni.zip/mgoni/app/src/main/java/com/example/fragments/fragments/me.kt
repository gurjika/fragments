package com.example.fragments.fragments

import androidx.fragment.app.Fragment
import com.example.fragments.R

class me: Fragment(R.layout.fragment_childhood) {
}